﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;
using System;

/**
 * PlayMaker custom action
 * Based on code by Jonathan O'Duffy and Andrew Jones - Fantasy to Reality - http://www.fantasytoreality.com.au/
 */
namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Kinect Actions")]
	[Tooltip("Allows you to detect phrases, defined in SpeechGrammar.grxml and recognized by the Kinect speech manager.")]
	
	public class RecognizePhrase : FsmStateAction
	{
		[Tooltip("Expected phrase tag, if there is any specific one.")]
		public FsmString expectedPhraseTag;
		
//		public enum PlayMakerUpdateCallType {Update,LateUpdate,FixedUpdate};
//		[Tooltip("Allow the user to determine which update to use.")]
//		public PlayMakerUpdateCallType updateCall;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the phrase tag recognized.")]
		public FsmString phraseTagRecognized;
		
		[Tooltip("Custom event to be sent on grammar phrase detection.")]
		public FsmEvent phraseDetectedEvent;
		
		private SpeechManager manager;


		// called when the state becomes active
		public override void OnEnter()
		{			
			phraseTagRecognized.Value = String.Empty;
		}
		
//		public override void OnLateUpdate()
//		{
//			if (updateCall == PlayMakerUpdateCallType.LateUpdate)
//			{
//				checkSpeechRecognizerStatus();			
//			}
//		}
//		
//		public override void OnFixedUpdate()
//		{
//			if (updateCall == PlayMakerUpdateCallType.FixedUpdate)
//			{
//				checkSpeechRecognizerStatus();			
//			}
//		}
		
		public override void OnUpdate()
		{
//			if (updateCall == PlayMakerUpdateCallType.Update)
			{
				checkSpeechRecognizerStatus();			
			}
		}
		
		private void checkSpeechRecognizerStatus()
		{		
			if(manager == null)
			{
				manager = SpeechManager.Instance;
			}
			
			if(manager != null && manager.IsSapiInitialized())
			{
				if(manager.IsPhraseRecognized())
				{
					phraseTagRecognized.Value = manager.GetPhraseTagRecognized();

					if(phraseDetectedEvent != null &&
						(expectedPhraseTag.Value == String.Empty || expectedPhraseTag.Value.Equals(phraseTagRecognized.Value, StringComparison.CurrentCultureIgnoreCase)))
					{
						manager.ClearPhraseRecognized();
						Fsm.Event(phraseDetectedEvent);
					}
				}
				else
				{
					//phraseTagRecognized.Value = String.Empty;
				}
			}
		}
	}
}